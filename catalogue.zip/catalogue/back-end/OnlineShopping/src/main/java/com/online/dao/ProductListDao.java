package com.online.dao;

import java.util.List;

import com.online.bean.ProductDetails;

public interface ProductListDao {
	ProductDetails createProductDetails(ProductDetails productlist);
	List<ProductDetails> getAllProduct();
	ProductDetails getByProductId(int id);
	ProductDetails getByName(String name);
	List<ProductDetails> getByProductPrice(String price);
	List<ProductDetails> getByProductCategory(String category);
	List<ProductDetails> searchByCategoryandPrice(String search);

}
