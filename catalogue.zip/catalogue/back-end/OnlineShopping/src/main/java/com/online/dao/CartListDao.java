package com.online.dao;

import java.util.List;

import com.online.bean.CartDetails;
import com.online.bean.ProductDetails;

public interface CartListDao {
	 void addToCart1(ProductDetails productdetails);
	List<CartDetails> getAllCart();
	Boolean deletecart(String id);

}
