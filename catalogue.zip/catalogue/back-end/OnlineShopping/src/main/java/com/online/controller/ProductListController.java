package com.online.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.online.bean.ProductDetails;
import com.online.service.ProductListService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins="http://localhost:4200")
public class ProductListController {
	
	@Autowired
	ProductListService productservice;
	List<ProductDetails> productsList=null;
	
	
	
	@PostMapping("/upload")
	public ResponseEntity<List<ProductDetails>> saveProduct(@RequestParam("file") MultipartFile projectdata) throws IOException{
		String line,name="C:\\Users\\vkorlam\\OneDrive - Capgemini\\Desktop\\"+projectdata.getOriginalFilename();
		FileReader fr=new FileReader(name);
		BufferedReader br=new BufferedReader(fr);
		ProductDetails product1=new ProductDetails();
		
		while((line=br.readLine())!=null) {
			ProductDetails product=new ProductDetails();
			String []data=line.split(",");
			
			product.setProId(data[0]);
			product.setProName(data[1]);
			product.setProDesc(data[2]);
			product.setProPrice(data[3]);
			product.setProCategory(data[4]);
			product.setImageUrl(data[5]);
			
			
			productservice.createProductDetails(product);
		}
	
	if(product1!=null) {
		System.out.println("succesfully added");
	    return new ResponseEntity(productsList,HttpStatus.OK);
	    }
	System.out.println("not added");
	return new ResponseEntity(null,HttpStatus.NOT_FOUND);
 }

	
	@PostMapping("/create")
	public ProductDetails createProduct(@RequestBody ProductDetails productdetails) {
		return productservice.createProductDetails(productdetails);
		
	}
	
	@GetMapping("/getall")
	public List<ProductDetails> getProduct(){
		return productservice.getAllProduct();
		
	}
	
	
	@GetMapping("/getByProductId")
	public ProductDetails getByProductId(@RequestParam("id") int id)
	{
	return productservice.getByProductId(id);
	}
	
	
	
	
	@GetMapping("/getByProductName")
	public ProductDetails getByName(@RequestParam("name") String name) {
		return productservice.getByName(name);
	}
	
	@GetMapping("/getByProudctPrice")
	public List<ProductDetails> getByProductPrice(@RequestParam("price") String price) {
		return productservice.getByProductPrice(price);
	}
	
	@GetMapping("/getByCategory/{categoryName}")
	public List<ProductDetails> getByCategory(@PathVariable("categoryName") String categoryName) {
		System.out.println(categoryName);
		return productservice.getByProductCategory(categoryName);
	}
	
	@GetMapping("/getProducts")
	public ResponseEntity<List<ProductDetails>> getProducts()
	{
		System.out.println("hello");
		productsList=productservice.getAllProduct();
	  //  System.out.println(productsList);
		if(productsList==null) {
			return new ResponseEntity("No data found",HttpStatus.NOT_FOUND);
		}
	    return new ResponseEntity<List<ProductDetails>>(productsList,HttpStatus.OK);
	}
	
	@GetMapping("/getByCategoryandPrice")
	public List<ProductDetails> search(@RequestParam("search") String search) {
		return productservice.searchByCategoryandPrice(search);
	}
	

}
