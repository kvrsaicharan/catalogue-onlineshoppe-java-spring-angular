import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { OnlineserviceService } from '../onlineservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  dataone:any[];
  products: any[]=[];
  products1: any[]=[];
  constructor(private userservice:OnlineserviceService,private productservice:ProductserviceService) { }
  name:String;
  searchName=true;
  searchId=false;
  searchterm:any;
  
  private _searchterm:string;
  searchterm1:any;
  
  ngOnInit() {
  }
  searchByMensware(){
    console.log("In Search")
    this.name="Men's Ware";
    console.log(this.name)
    this.productservice.getProductsByCategory(this.name).
    subscribe((data:any)=>{this.products=data;console.log(this.products)});
  }

  searchByEthnicwomen(){
    console.log("In Search")
    this.name="Ethnic Women";
    this.productservice.getProductsByCategory(this.name).subscribe((data:any)=>this.products=data);
  }

  searchByBaby(){
    console.log("In Search")
    this.name="Baby";
    this.productservice.getProductsByCategory(this.name).subscribe((data:any)=>this.products=data);
  }
  searchBywomenware(){
    console.log("In Search")
    this.name="Women's ware";
    this.productservice.getProductsByCategory(this.name).subscribe((data:any)=>this.products=data);
  }
  searchByMobiles(){
    console.log("In Search")
    this.name="Mobiles";
    this.productservice.getProductsByCategory(this.name).subscribe((data:any)=>this.products=data);
  }
}
