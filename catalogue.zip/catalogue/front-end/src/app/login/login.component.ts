import { Component, OnInit } from '@angular/core';
import { OnlineserviceService } from '../onlineservice.service';
import { Router } from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  model: any = {};
  res: number;
  result: string;
  constructor(private onlineService: OnlineserviceService, private router: Router) { }


  ngOnInit() {
  }
  onLogin() {
    console.log(this.model.id)
    return this.onlineService.validateLogin(this.model.id, this.model.password).subscribe((data: number) => {
      this.res = data;
      console.log(this.res);
      if (this.res == 1) {
        this.router.navigate(["/adminproducts"])
      }
      else if (this.res == 2) {
        this.router.navigate(["/products"])
      }
      else {
        alert("Enter Valid Credentials")
      }

    })

  }
}