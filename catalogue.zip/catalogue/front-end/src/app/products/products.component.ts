import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { OnlineserviceService } from '../onlineservice.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  dataone:any[];
  products: any[]=[];
  products1: any[]=[];
  constructor(private userservice:OnlineserviceService,private productservice:ProductserviceService) { }

  name:String;
  searchName=true;
  searchId=false;
  searchterm:any;
  
  private _searchterm:string;
  searchterm1:any;
  

  ngOnInit() {
    return this.userservice.getdata().subscribe((data:any)=>{this.dataone=data 
      console.log(this.dataone)});
  }
  
    //this.router.navigate(['/search']);
    search(searchterm){
      console.log("in string");
      this.productservice.searchByName(searchterm).subscribe((data:any)=>this.products=data);       
      }
  addToCart(prod){
    console.log(".ts angular")
    console.log(prod);
     this.productservice.addToCart(prod).subscribe();
     window.alert("Added succesfully");
  
  }
  
}
