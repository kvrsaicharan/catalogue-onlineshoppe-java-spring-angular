import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  dataone:any[];

  constructor(private productService:ProductserviceService) { }

  ngOnInit() {
    this.productService.getaddedcartproducts().subscribe((prod:any)=>{this.dataone=prod
      console.log(this.dataone);
      //console.log(prod.totalPrice);
    });
  
  }
 /*  cart(){
    this.productService.getaddedcartproducts().subscribe((prod:any)=>{this.dataone=prod
      console.log(this.dataone);
      
    }); 
  } */
  delete(id){
    console.log(id);
  /*   let index=this.dataone.indexOf(product);
    this.dataone.splice(index,1); */
    this.productService.deletecart(id).subscribe(); 
    alert("Product deleted Successfully");
  }

}
