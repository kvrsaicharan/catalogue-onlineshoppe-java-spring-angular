import { Injectable } from '@angular/core';/* 
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Router } from '../../node_modules/@angular/router'; */
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  constructor(private http:HttpClient,private router:Router) { }
  getaddedcartproducts(){
    console.log("in servivce");
    return this.http.get("http://localhost:9639/cartlist/getAll");
  }
 
  /* getCartProducts(){
    console.log("in servivce");
    
    return this.http.get("http://localhost:9633/cartlist/getAll");
  } */
  deletecart(id:any){
    console.log("in serviceeeeeeeeee")
    console.log(id);
    return this.http.delete("http://localhost:9639/cartlist/deleteproduct/"+id);
    
  }

  getProductsByCategory(name:String){
    console.log("ffff"+name)
    return this.http.get("http://localhost:9639/product/getByCategory/"+name);
  }
 
  searchByName(search:string){
    return this.http.get("http://localhost:9639/product/getByCategoryandPrice?search="+search);
    }

  addToCart(prod:any){
  let input={
       "proId":prod.proId,
       "proName":prod.proName,
       "proDesc":prod.proDesc,
       "proPrice":prod.proPrice,
       "proCategory":prod.proCategory,
       "imageUrl":prod.imageUrl
     } 
     console.log("in service"+input.proCategory);

    return  this.http.post("http://localhost:9639/cartlist/add",input);
   }

}
